
#include "std_msgs/String.h"
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/Vector3.h>
#include <nav_msgs/Odometry.h>
#include "ros/ros.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/static_transform_broadcaster.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <geometry_msgs/TransformStamped.h>
#include "tf2/transform_datatypes.h"
#include <tf2_ros/transform_broadcaster.h>
#include <cmath>
#include <vector>

auto createQuaternionMsgFromYaw(double yaw) {
  tf2::Quaternion q;
  geometry_msgs::Quaternion quat_msg;

  q.setRPY(0, 0, yaw);

  return q;
}

//This file broadcasts the static transformation between 
//world reference frame and odom reference frame
int main(int argc, char **argv) {

  ros::init(argc, argv, "world_odom_broadcaster");

  static tf2_ros::StaticTransformBroadcaster tf_br_;
  geometry_msgs::TransformStamped world_trans;

  tf2::Quaternion quat = createQuaternionMsgFromYaw(0.0);

  // set up parent and child frames
  world_trans.header.stamp= ros::Time::now();
  world_trans.header.frame_id= "world";
  world_trans.child_frame_id= "odom";
  world_trans.transform.translation.x=0.008026;
  world_trans.transform.translation.y=0.002688;

  world_trans.transform.translation.z=0.368733;
  world_trans.transform.rotation.x=quat.x();
  world_trans.transform.rotation.y=quat.y();
  world_trans.transform.rotation.z=quat.z();
  world_trans.transform.rotation.w=quat.w();

  tf_br_.sendTransform(world_trans);

  // set up publish rate

  // main loop
  ros::spin();

  return 0;
}


