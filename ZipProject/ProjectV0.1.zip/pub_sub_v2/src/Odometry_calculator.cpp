#include "std_msgs/String.h"
#include "pub_sub/Num.h"
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/TwistStamped.h>
#include "ros/ros.h"
#include <cmath>




class odometry_calculator{
public:

  odometry_calculator(){
  	/*
    this->r = 0.07;
    this->Lx = 0.2;
    this->Ly = 0.169;
    this->T = 5;
    this->N = 42;
    this->old_nsec = 0;
    this->old_ticks_fl = 0;
    this->old_ticks_fr = 0;
    this->old_ticks_rl = 0;
    this->old_ticks_rr = 0;


    this->velocity_subscriber = this->n.subscribe("wheel_states", 1000, &velocity_sub::counterCallback,this);
    this->velocity_publisher = this->n.advertise<geometry_msgs::TwistStamped>("cmd_velo", 1000);
    */

    this->old_nsec = 0;
    this->position_x = 0.008025641553103924;
    this->position_y = 0.002688170177862048;
    this->position_z = 0.36873340606689453;
    this->theta = 0.0616083;


  	this->velocity_for_odom_subscriber = this->n.subscribe("cmd_velo", 1000, &odometry_calculator::getVelocity,this);


  }

  void run(){

    ros::spin();


  }


  void getVelocity(const geometry_msgs::TwistStamped::ConstPtr& msg) {
    
  	float Vx = msg->twist.linear.x;
  	float Vy = msg->twist.linear.y;
  	float Wz = msg->twist.angular.z;

    //float module = sqrt(pow(Vx,2)+pow(Vy,2))
    //float angle = atan2(Vy/Vx)

    float V_abs_x = Vx*cos(this->theta) - Vy *sin(this->theta);

    float V_abs_y = Vx*sin(this->theta) + Vy*cos(this->theta);

  	double new_nsec= msg->header.stamp.nsec;
  	double dtime =(new_nsec - this->old_nsec)/1000000000;

  	//ROS_INFO("Vx: [%f]",this->Vx);
    //ROS_INFO("Vy: [%f]",this->Vy);
    //ROS_INFO("Vz: [%f]",this->Wz);

    float new_position_x= this->position_x + V_abs_x*dtime;
    float new_position_y= this->position_y + V_abs_y*dtime; 
    float new_theta= this->theta + Wz*dtime;

    this->position_x = new_position_x;
    this->position_y = new_position_y;
    this->theta = new_theta;

    ROS_INFO("X: [%f]",this->position_x);
    ROS_INFO("Y: [%f]",this->position_y);
    ROS_INFO("Theta: [%f]",this->theta);
    

  }




private:
	ros::NodeHandle n;
	ros::Subscriber velocity_for_odom_subscriber;
	//float Vx;
	//float Vy;
	//float Wz;

	float position_x;
	float position_y;
	float position_z;

	float theta;
	double old_nsec;


  /*
  ros::NodeHandle n;
  ros::Subscriber velocity_subscriber;
  //int old_sec;
  double old_nsec;
  float old_ticks_fl;     
  float old_ticks_fr;
  float old_ticks_rl;
  float old_ticks_rr;
  float r;
  float Lx;
  float Ly;
  int T;
  int N;

  ros::Publisher velocity_publisher;
  */


  

};

int main(int argc, char **argv) {
  ros::init(argc, argv, "odometry_calculator");
  
  odometry_calculator my_odometry_calculator;
  my_odometry_calculator.run();

  return 0;
}
