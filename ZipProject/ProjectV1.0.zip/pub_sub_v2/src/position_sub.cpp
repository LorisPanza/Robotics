#include "std_msgs/String.h"
#include "pub_sub/Num.h"
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/PoseStamped.h>
#include "ros/ros.h"
#include <cmath>
#define _USE_MATH_DEFINES
//#include "math.h"


//void chatterCallback(const std_msgs::String::ConstPtr& msg) {
  //ROS_INFO("I heard: [%s]", msg->data.c_str());
//}

/*
int old_sec=0;
int old_nsec=0;
float old_ticks_fl=0;
float old_ticks_fr=0;
float old_ticks_rl=0;
float old_ticks_rr=0;


*/


struct Quaternion {
    double w, x, y, z;
};

struct EulerAngles {
    double roll, pitch, yaw;
};



EulerAngles ToEulerAngles(Quaternion q) {
    EulerAngles angles;

    // roll (x-axis rotation)
    double sinr_cosp = 2 * (q.w * q.x + q.y * q.z);
    double cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y);
    angles.roll = std::atan2(sinr_cosp, cosr_cosp);

    // pitch (y-axis rotation)
    double sinp = 2 * (q.w * q.y - q.z * q.x);
    if (std::abs(sinp) >= 1)
        angles.pitch = std::copysign(M_PI / 2, sinp); // use 90 degrees if out of range
    else
        angles.pitch = std::asin(sinp);

    // yaw (z-axis rotation)
    double siny_cosp = 2 * (q.w * q.z + q.x * q.y);
    double cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z);
    angles.yaw = std::atan2(siny_cosp, cosy_cosp);

    return angles;
}

class position_sub{
public:

  position_sub(){


    this->position_subscriber = this->n.subscribe("robot/pose", 2, &position_sub::counterCallback,this);

  }

  void run(){

    ros::spin();


  }


  void counterCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {
    Quaternion quat;
    quat.w=msg->pose.orientation.w;
    quat.x=msg->pose.orientation.x;
    quat.y=msg->pose.orientation.y;
    quat.z=msg->pose.orientation.z;

    EulerAngles angles= ToEulerAngles(quat);
    //ROS_INFO("Position: X:[%f] , Y:[%f]", msg->pose.position.x, msg->pose.position.y);
    //ROS_INFO("Orientation: Theta[%f]", angles.yaw);


    //const sensor_msgs::JointState::ConstPtr& msg

    

  }

private:

  
  ros::NodeHandle n;
  ros::Subscriber position_subscriber;
  

  

};

int main(int argc, char **argv) {
  ros::init(argc, argv, "position_calculator");
  
  position_sub my_position_sub;
  my_position_sub.run();

  return 0;
}