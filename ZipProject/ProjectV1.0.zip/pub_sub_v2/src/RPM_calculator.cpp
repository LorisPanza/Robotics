#include "std_msgs/String.h"
#include "pub_sub/WheelsRPM.h"
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/TwistStamped.h>
#include "ros/ros.h"
#include <cmath>

class rpm_calculator{
public:

  rpm_calculator(){

  	this->r = 0.07;
    this->Lx = 0.2;
    this->Ly = 0.169;
    this->T = 5;
    this->N = 42;
    

  	 this->rpm_vel_sub = this->n.subscribe("cmd_velo", 2, &rpm_calculator::counterCallback,this);
  	 this->rpm_vel_pub = this->n.advertise<pub_sub::WheelsRPM>("wheels_rpm",2);


  }

  void run(){

    ros::spin();


  }


  void counterCallback(const geometry_msgs::TwistStamped::ConstPtr& msg) {
    //ROS_INFO("I counted: [%f],[%f], [%f],[%f]", msg->velocity[0], msg->velocity[1],msg->velocity[2], msg->velocity[3]);
    //const sensor_msgs::JointState::ConstPtr& msg

    double Vx = msg->twist.linear.x;
  	double Vy = msg->twist.linear.y;
  	double Wz = msg->twist.angular.z;


  	double RPMfl = ((Vx - Vy - (this->Lx+this->Ly)*Wz)*60*this->T)/(r);
  	double RPMfr = ((Vx + Vy + (this->Lx+this->Ly)*Wz)*60*this->T)/(r);
  	double RPMrl = ((Vx + Vy - (this->Lx+this->Ly)*Wz)*60*this->T)/(r);
  	double RPMrr = ((Vx - Vy + (this->Lx+this->Ly)*Wz)*60*this->T)/(r);

	//ROS_INFO("I counted: [%f],[%f], [%f],[%f]", RPMfl, RPMfr,RPMrl, RPMrr);

	pub_sub::WheelsRPM rpm_msg;

	rpm_msg.header.frame_id = "RPMFromTIcks";
	rpm_msg.header.stamp = ros::Time::now();

	rpm_msg.rpm_fl = RPMfl;
	rpm_msg.rpm_fr = RPMfr;
	rpm_msg.rpm_rl = RPMrl;
	rpm_msg.rpm_rr = RPMrr;

	this->rpm_vel_pub.publish(rpm_msg);



    
  }

private:
	ros::NodeHandle n;
	ros::Subscriber rpm_vel_sub;
	ros::Publisher rpm_vel_pub;
	float r;
	float Lx;
	float Ly;
	float T;
	float N;

};


int main(int argc, char **argv) {
  ros::init(argc, argv, "rpm_calculator");
  
  rpm_calculator my_rpm_calculator;
  my_rpm_calculator.run();

  return 0;
}
