#include "std_msgs/String.h"
#include "pub_sub/Num.h"
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/Vector3.h>
#include <nav_msgs/Odometry.h>
#include "ros/ros.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <geometry_msgs/TransformStamped.h>
#include "tf2/transform_datatypes.h"
#include <tf2_ros/transform_broadcaster.h>
#include <cmath>
#include <vector>
#include "pub_sub/Reset.h"
#include <pub_sub/parametersConfig.h>
#include <dynamic_reconfigure/server.h>




class odometry_calculator{
public:
  ros::NodeHandle n;

  odometry_calculator(){
  	

    //this->odometry_Euler = false;

    this->old_nsec;
    this->counter = 0;
    this->old_sec;
    this->cont=0;

    /*

    this->position_x = 0.008025641553103924;
    this->position_y = 0.002688170177862048;
    this->position_z = 0.36873340606689453;
    this->theta = 0.0616083;
    */

    

    std::vector<float> ini_pos;

    this->n.getParam("/odometry_initial_pose",ini_pos);


    ROS_INFO("Ini_x: [%f]",ini_pos[0]);
    ROS_INFO("Ini_y: [%f]",ini_pos[1]);
    ROS_INFO("Ini_z: [%f]",ini_pos[2]);
    ROS_INFO("Ini_theta: [%f]",ini_pos[3]);


    this->position_x = ini_pos[0];
    this->position_y = ini_pos[1];
    this->position_z = ini_pos[2];
    this->theta = ini_pos[3];



  	this->velocity_for_odom_subscriber = this->n.subscribe("cmd_velo", 2, 
      &odometry_calculator::computeOdometry,this);
    this->odometry_publisher = this->n.advertise<nav_msgs::Odometry>("odom", 2);

    this->ss = this->n.advertiseService("resetPosition",
      &odometry_calculator::resetPosition,this);

    this->integration_method = 0;

    this->f = boost::bind(&method_callback,&integration_method,_1,_2);
    this->dynMethod.setCallback(this->f);

  }

  void run(){

    ros::spin();


  }


   static void method_callback(int* integration_method, pub_sub::parametersConfig &config, uint32_t level){

    ROS_INFO("Reconfigure Request: [%d]",config.integration_method);
    *integration_method = config.integration_method;




  }





  bool resetPosition(pub_sub::Reset::Request &req, pub_sub::Reset::Response &res){


  this->position_x = req.x;
  this->position_y = req.y;
  this->theta = req.theta;
   return true;
  


    }




  auto createQuaternionMsgFromYaw(double yaw) {
    tf2::Quaternion q;
    geometry_msgs::Quaternion quat_msg;

    q.setRPY(0, 0, yaw);

    //tf2::convert(q,quat_msg);

    return q; //quat_msg;
  }


  void computeOdometry(const geometry_msgs::TwistStamped::ConstPtr& msg) {

    if(this->counter == 0){

       this->old_sec = msg->header.stamp.sec;
       this->old_nsec = msg->header.stamp.nsec;
       this->counter = 1;
       this->cont;
       return;


      }



    //Velocity robot reference from topic cmd_velo
    
  	float Vx = msg->twist.linear.x;
  	float Vy = msg->twist.linear.y;
  	float Wz = msg->twist.angular.z;


    //Second differences between two messages on the cmd_velo topic 

    double new_nsec= msg->header.stamp.nsec;
    double conv_old_nsec = (this->old_nsec/1000000000);
    double conv_new_nsec = (new_nsec/1000000000);
    double new_sec = msg->header.stamp.sec;
    double new_time = new_sec + conv_new_nsec;
    double old_time = this->old_sec + conv_old_nsec;


  	double dtime =(new_time - old_time);
    float V_abs_x;
    float V_abs_y;


    //Velocity word reference for Euler and Range Kutta

    if(this->integration_method==1){

      //ROS_INFO("Uso Euler!");

      V_abs_x = Vx*cos(this->theta) - Vy*sin(this->theta);

      V_abs_y = Vx*sin(this->theta) + Vy*cos(this->theta);
    

    }
    else{

      //ROS_INFO("Uso Runge_Kutta!");

      V_abs_x = Vx*cos(this->theta + (Wz*dtime)/2) - Vy*sin(this->theta + (Wz*dtime)/2);

      V_abs_y = Vx*sin(this->theta + (Wz*dtime)/2) + Vy*cos(this->theta + (Wz*dtime)/2);

      }

  	//ROS_INFO("Vx: [%f]",this->Vx);
    //ROS_INFO("Vy: [%f]",this->Vy);
    //ROS_INFO("Vz: [%f]",this->Wz);


    // New pose predicted
      
    float new_position_x= this->position_x + V_abs_x*dtime;
    float new_position_y= this->position_y + V_abs_y*dtime; 
    float new_theta= this->theta + Wz*dtime;


    //PUBLISHER odometry on odom

    //nav_msgs requires Quaternion, we need to convert the predicted theta into quaternion

    //current_time = ros::Time::now();



    

    tf2::Quaternion odom_quat = createQuaternionMsgFromYaw(new_theta);



    nav_msgs::Odometry odom;
    odom.header.stamp = msg->header.stamp;
    odom.header.frame_id = "odom";
 
     //set the predicted position (world reference)
    odom.pose.pose.position.x = new_position_x;
    odom.pose.pose.position.y = new_position_y;
    odom.pose.pose.position.z = 0.0;
    //odom.pose.pose.orientation = odom_quat;


    odom.pose.pose.orientation.x = odom_quat.x();
    odom.pose.pose.orientation.y = odom_quat.y();
    odom.pose.pose.orientation.z = odom_quat.z();
    odom.pose.pose.orientation.w = odom_quat.w();
 
     //set the velocity (robot reference or world reference?)
    odom.child_frame_id = "base_link";
    odom.twist.twist.linear.x = Vx;
    odom.twist.twist.linear.y = Vy;
    odom.twist.twist.angular.z = Wz;
 
     //publish the message
    odometry_publisher.publish(odom);


    


    //if(this->cont%10000==0){


    geometry_msgs::TransformStamped odom_trans;
    tf2_ros::TransformBroadcaster odom_broadcaster;


    odom_trans.header.stamp = ros::Time::now();
    odom_trans.header.frame_id = "odom";
    odom_trans.child_frame_id = "base_link";
   
    odom_trans.transform.translation.x = new_position_x;
    odom_trans.transform.translation.y = new_position_y;
    odom_trans.transform.translation.z = 0.0;
    odom_trans.transform.rotation.x = odom_quat.x();
    odom_trans.transform.rotation.y = odom_quat.y();
    odom_trans.transform.rotation.z = odom_quat.z();
    odom_trans.transform.rotation.w = odom_quat.w();



    odom_broadcaster.sendTransform(odom_trans);


  //}

    //this->cont++;

  

    //ROS_INFO("X_base_link:[%f]",odom_trans.transform.translation.x );
    //ROS_INFO("Y_base_link: [%f]",odom_trans.transform.translation.y);
    //ROS_INFO("Z_base_link:[%f]",odom_trans.transform.translation.z);
    //ROS_INFO("QUAT_base_link:",odom_trans.transform.rotation);

    

    //Updating variables
    this->position_x = new_position_x;
    this->position_y = new_position_y;
    this->theta = new_theta;

    this->old_nsec = new_nsec;
    this->old_sec = new_sec;



    //ROS_INFO("X: [%f]",this->position_x);
    //ROS_INFO("Y: [%f]",this->position_y);
    //ROS_INFO("Theta: [%f]",this->theta);

  }




private:
	
	ros::Subscriber velocity_for_odom_subscriber;
  ros::Publisher odometry_publisher;
  ros::ServiceServer ss;
  dynamic_reconfigure::Server<pub_sub::parametersConfig> dynMethod;
  dynamic_reconfigure::Server<pub_sub::parametersConfig>::CallbackType f;
  int integration_method;
	//float Vx;
	//float Vy;
	//float Wz;

	float position_x;
	float position_y;
	float position_z;
  int counter;

	float theta;
	double old_nsec;
  double old_sec;
  bool odometry_Euler;
  int cont;
  

};

int main(int argc, char **argv) {
  ros::init(argc, argv, "odometry_calculator");
  
  odometry_calculator my_odometry_calculator;
  my_odometry_calculator.run();

  



  return 0;
}
