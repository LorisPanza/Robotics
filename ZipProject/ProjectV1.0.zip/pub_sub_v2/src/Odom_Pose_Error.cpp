
#include "std_msgs/String.h"
#include "pub_sub/Num.h"
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/Vector3.h>
#include <nav_msgs/Odometry.h>
#include "ros/ros.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/static_transform_broadcaster.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <geometry_msgs/TransformStamped.h>
#include "tf2/transform_datatypes.h"
#include <tf2_ros/transform_broadcaster.h>
#include <cmath>
#include <vector>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/subscriber.h>
 #include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>


#include <sstream>



struct Quaternion {
    double w, x, y, z;
};

struct EulerAngles {
    double roll, pitch, yaw;
};



EulerAngles ToEulerAngles(Quaternion q) {
    EulerAngles angles;

    // roll (x-axis rotation)
    double sinr_cosp = 2 * (q.w * q.x + q.y * q.z);
    double cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y);
    angles.roll = std::atan2(sinr_cosp, cosr_cosp);

    // pitch (y-axis rotation)
    double sinp = 2 * (q.w * q.y - q.z * q.x);
    if (std::abs(sinp) >= 1)
        angles.pitch = std::copysign(M_PI / 2, sinp); // use 90 degrees if out of range
    else
        angles.pitch = std::asin(sinp);

    // yaw (z-axis rotation)
    double siny_cosp = 2 * (q.w * q.z + q.x * q.y);
    double cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z);
    angles.yaw = std::atan2(siny_cosp, cosy_cosp);

    return angles;
}



void callback(float *counter_x,float *counter_y,float *counter_theta,
	const nav_msgs::Odometry::ConstPtr& odom,const geometry_msgs::PoseStamped::ConstPtr& pose) {
 	
	ROS_INFO("Sec odom: [%d]",odom->header.stamp.sec);
	ROS_INFO("Sec odom: [%d]",odom->header.stamp.nsec);

	ROS_INFO("Sec pose: [%d]",pose->header.stamp.sec);
	ROS_INFO("Sec pose: [%d]",pose->header.stamp.nsec);
	float cum_error_x= *counter_x;
	float cum_error_y= *counter_y;
	float cum_error_theta= *counter_theta;

	Quaternion q_pose;
	q_pose.x = pose->pose.orientation.x;
	q_pose.y = pose->pose.orientation.y;
	q_pose.z = pose->pose.orientation.z;
	q_pose.w = pose->pose.orientation.w;


	Quaternion q_odom;
	q_odom.x = odom->pose.pose.orientation.x;
    q_odom.y = odom->pose.pose.orientation.y;
	q_odom.z = odom->pose.pose.orientation.z;
	q_odom.w = odom->pose.pose.orientation.w;


	float theta_pose = ToEulerAngles(q_pose).yaw;
	float theta_odom = ToEulerAngles(q_odom).yaw;


	cum_error_x = cum_error_x + abs(pose->pose.position.x - odom->pose.pose.position.x);
	cum_error_y = cum_error_y + abs(pose->pose.position.y - odom->pose.pose.position.y);
	cum_error_theta = cum_error_theta + abs(theta_pose - theta_odom);
	//cum_error_z = pose->;




	*counter_x= cum_error_x;
	*counter_y= cum_error_y;
	*counter_theta=cum_error_theta;

	ROS_INFO("Error x: [%f]",cum_error_x);
	ROS_INFO("Error y: [%f]",cum_error_y);
	ROS_INFO("Error theta: [%f]",cum_error_theta);
	




 }



int main(int argc, char **argv) {
  ros::init(argc, argv, "talker");
  ros::NodeHandle n;
  float counter_x=0;
  float counter_y=0;
  float counter_theta=0;

  //ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);
  //ros::Publisher counter_pub = n.advertise<pub_sub::Num>("counter", 1000);

message_filters::Subscriber<nav_msgs::Odometry> sub1(n, "odom",1);
message_filters::Subscriber<geometry_msgs::PoseStamped> sub2(n, "robot/pose",1);

typedef message_filters::sync_policies::ApproximateTime<nav_msgs::Odometry,geometry_msgs::PoseStamped> MySyncPolicy;

message_filters::Synchronizer<MySyncPolicy> sync(MySyncPolicy(10), sub1, sub2);

//message_filters::TimeSynchronizer<nav_msgs::Odometry,geometry_msgs::PoseStamped> sync(sub1, sub2, 10);

sync.registerCallback(boost::bind(&callback,&counter_x,&counter_y,&counter_theta, _1, _2));


ros::spin();

  

  return 0;
}





