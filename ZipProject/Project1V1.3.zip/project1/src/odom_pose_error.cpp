#include "std_msgs/String.h"
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/Vector3.h>
#include <nav_msgs/Odometry.h>
#include "ros/ros.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/static_transform_broadcaster.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <geometry_msgs/TransformStamped.h>
#include "tf2/transform_datatypes.h"
#include <tf2_ros/transform_broadcaster.h>
#include <cmath>
#include <vector>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <sstream>

struct Quaternion {
    double w, x, y, z;
};

struct EulerAngles {
    double roll, pitch, yaw;
};

//function to retrieve the Euler angle from the relative Quaternion

EulerAngles ToEulerAngles(Quaternion q) {
    EulerAngles angles;

    // roll (x-axis rotation)
    double sinr_cosp = 2 * (q.w * q.x + q.y * q.z);
    double cosr_cosp = 1 - 2 * (q.x * q.x + q.y * q.y);
    angles.roll = std::atan2(sinr_cosp, cosr_cosp);

    // pitch (y-axis rotation)
    double sinp = 2 * (q.w * q.y - q.z * q.x);
    if (std::abs(sinp) >= 1)
        angles.pitch = std::copysign(M_PI / 2, sinp); // use 90 degrees if out of range
    else
        angles.pitch = std::asin(sinp);

    // yaw (z-axis rotation)
    double siny_cosp = 2 * (q.w * q.z + q.x * q.y);
    double cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z);
    angles.yaw = std::atan2(siny_cosp, cosy_cosp);

    return angles;
}

//Callback function to calculate the error on x,y and theta values
//Difference between odom and pose values
//For x and y the error is the square root of the squared sum of x difference and y difference

void errorCallback(float *counter,float *counter_theta,
	const nav_msgs::Odometry::ConstPtr& odom,const geometry_msgs::PoseStamped::ConstPtr& pose) {
 	
	float cum_error = *counter;
	float cum_error_theta= *counter_theta;

	Quaternion q_pose;
	q_pose.x = pose->pose.orientation.x;
	q_pose.y = pose->pose.orientation.y;
	q_pose.z = pose->pose.orientation.z;
	q_pose.w = pose->pose.orientation.w;


	Quaternion q_odom;
	q_odom.x = odom->pose.pose.orientation.x;
    q_odom.y = odom->pose.pose.orientation.y;
	q_odom.z = odom->pose.pose.orientation.z;
	q_odom.w = odom->pose.pose.orientation.w;


	float theta_pose = ToEulerAngles(q_pose).yaw;
	float theta_odom = ToEulerAngles(q_odom).yaw;

	cum_error_theta = cum_error_theta + abs(theta_pose - theta_odom);

	float diff_x = pose->pose.position.x - odom->pose.pose.position.x;
	float diff_y = pose->pose.position.y - odom->pose.pose.position.y;

	cum_error = cum_error + sqrt(pow(diff_x,2) + pow(diff_y,2));

	*counter= cum_error;
	*counter_theta=cum_error_theta;

	//by decommenting it is possible to print the cumulative geometric distance between
	//the real and estimated points at each timestamp
	//These values were necessary to calibrate the robot parameters (r, l, w, N)
	//ROS_INFO("Cumulated (x,y) error: [%f]",cum_error);
	//ROS_INFO("Error theta: [%f]",cum_error_theta);
}



int main(int argc, char **argv) {
	ros::init(argc, argv, "talker");
	ros::NodeHandle n;
	float counter=0;
	float counter_theta=0;


	//The two topic messages (odom and pose) are taken at the similar timestamp using
	//the sync_policy ApproximateTime 

	message_filters::Subscriber<nav_msgs::Odometry> sub1(n, "odom",1);
	message_filters::Subscriber<geometry_msgs::PoseStamped> sub2(n, "robot/pose",1);

	typedef message_filters::sync_policies::ApproximateTime<nav_msgs::Odometry,geometry_msgs::PoseStamped> MySyncPolicy;

	message_filters::Synchronizer<MySyncPolicy> sync(MySyncPolicy(10), sub1, sub2);

	sync.registerCallback(boost::bind(&errorCallback,&counter,&counter_theta, _1, _2));

	ros::spin();
	return 0;
}








