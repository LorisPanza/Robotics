#include "std_msgs/String.h"
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include "ros/ros.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <geometry_msgs/TransformStamped.h>
#include "tf2/transform_datatypes.h"
#include <tf2_ros/transform_broadcaster.h>
#include "project2/savemap.h"
#include <cmath>
#include <vector>
#include <stdlib.h>
#include <iostream>
#include <string.h>
#include <opencv2/opencv.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>
#include <opencv2/core/mat.hpp>
#include <ros/package.h>
#include <cv_bridge/cv_bridge.h>
#include "ros/package.h"

using namespace cv;

class map_saver{
public:
  ros::NodeHandle n;

  map_saver(){
    this->odom_subscriber = this->n.subscribe("odom", 2, &map_saver::createPath, this);
    this->path_publisher = this->n.advertise<nav_msgs::Path>("Path", 2);


    this->ss = this->n.advertiseService("mapSaver",
    &map_saver::mapSaver,this);
  }

  void run(){
  
    ros::spin();
  }

  void createPath(const nav_msgs::Odometry::ConstPtr& odom) {
    this->path.header = odom->header;

    geometry_msgs::PoseStamped pose;
    pose.header = odom->header;
    pose.pose = odom->pose.pose;
    this->path.poses.push_back(pose);

    this->path_publisher.publish(this->path);

  }

  bool mapSaver(project2::savemap::Request &req, project2::savemap::Response &res){
    String cur_dir = ros::package::getPath("project2");
    ROS_INFO_STREAM(cur_dir);
    Mat map = cv::imread(cur_dir + "/mapserver_images/" + req.filename + ".pgm");
    cv::imwrite(cur_dir + "/images/" + req.filename + ".png", map);
    return true;
  }


private:
  ros::Subscriber odom_subscriber;
  ros::Publisher path_publisher;

  ros::ServiceServer ss;
  nav_msgs::Path path;
};

int main(int argc, char **argv) {
  ros::init(argc, argv, "map_saver");
  
  map_saver my_map_saver;
  my_map_saver.run();

  return 0;
}