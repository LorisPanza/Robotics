#include "std_msgs/String.h"
#include <nav_msgs/Odometry.h>
#include "ros/ros.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <geometry_msgs/TransformStamped.h>
#include "tf2/transform_datatypes.h"
#include <tf2_ros/transform_broadcaster.h>
#include <cmath>
#include <vector>

//Class to define the variables and methods needed to calculate and 
//publish on topic "odom" our odometry

class odom_to_base_link{
public:
  ros::NodeHandle n;

  odom_to_base_link(){

    this->odom_subscriber = this->n.subscribe("odom", 2, &odom_to_base_link::transform_odom_to_base_link,this);

  }

  void run(){
  
    ros::spin();
  }


  //Method for the odometry calculation
  void transform_odom_to_base_link(const nav_msgs::Odometry::ConstPtr& odom) {

    //nav_msgs::Odometry odom;

    //Broadcast TF odom->base_link
    geometry_msgs::TransformStamped odom_trans;
    tf2_ros::TransformBroadcaster odom_broadcaster;

    odom_trans.header.stamp = odom->header.stamp;
    odom_trans.header.frame_id = "odom";
    odom_trans.child_frame_id = "base_link";
   
    odom_trans.transform.translation.x = odom->pose.pose.position.x; //new_position_x;
    odom_trans.transform.translation.y = odom->pose.pose.position.y;
    odom_trans.transform.translation.z = 0.0;
    odom_trans.transform.rotation.x = odom->pose.pose.orientation.x;
    odom_trans.transform.rotation.y = odom->pose.pose.orientation.y;
    odom_trans.transform.rotation.z = odom->pose.pose.orientation.z;
    odom_trans.transform.rotation.w = odom->pose.pose.orientation.w;

    odom_broadcaster.sendTransform(odom_trans);


  }




private:
    
  ros::Subscriber odom_subscriber;

};

int main(int argc, char **argv) {
  ros::init(argc, argv, "odom_to_base_link");
  
  odom_to_base_link my_odom_to_base_link;
  my_odom_to_base_link.run();

  return 0;
}